/*
 * Copyright Sean Owen
 */

package com.google.zxing.common.advanced.rowedge;

final class Transition {

  float center;
  int absDiffSum;
  boolean positive;

}
